-- RetailIQ SQL
SELECT Category,SUM(Sales) TotalSales FROM sales GROUP BY Category;
SELECT State,SUM(Profit) TotalProfit FROM sales GROUP BY State;
SELECT Customer,SUM(Sales) Revenue FROM sales GROUP BY Customer ORDER BY Revenue DESC LIMIT 10;
SELECT strftime('%m',OrderDate) Month,SUM(Sales) FROM sales GROUP BY Month;
