# RetailIQ: End-to-End Sales Analytics Platform

## Objective
Analyze retail sales data using SQL, Python, Excel, and Power BI.

## KPIs
- Total Sales
- Total Profit
- Profit Margin
- Orders
- Average Order Value

## Dashboard Pages
1. Executive Summary
2. Customer Analysis
3. Product Analysis
4. Regional Analysis

## Recommended Power BI visuals
Cards, Line Chart, Bar Chart, Map, Slicers, Treemap.
