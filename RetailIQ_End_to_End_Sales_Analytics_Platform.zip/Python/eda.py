import pandas as pd
import matplotlib.pyplot as plt

df=pd.read_csv('../Dataset/sales.csv')
print(df.head())
print(df.describe())
print(df.groupby('Category')['Sales'].sum())
